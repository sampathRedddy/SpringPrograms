package com.zensar.spring.boot.springinitializer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInitializerApplication  {
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringInitializerApplication.class, args);
		
		/*ConfigurableApplicationContext context = SpringApplication.run(SpringInitializerApplication.class, args);
	
		ProductController ctrl=(ProductController)context.getBean("productController");
		
		Product p=new Product(1,"TV",20000);
		
		ctrl.insertProduct(p);*/  
	}

	

}

