package com.zensar.spring.boot.springinitializer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.spring.boot.springinitializer.model.Product;
import com.zensar.spring.boot.springinitializer.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productService;

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public Iterable<Product> getAllProducts() {
		return productService.getAllProducts();
	}

	@RequestMapping(value = "/products/test/{id}", method = RequestMethod.GET)
	public Optional<Product> getProduct(@PathVariable("id") int id) {
		return productService.getProduct(id);
	}
	
	
	@RequestMapping(value = "/products/{name}", method = RequestMethod.GET)
	public List<Product> getProductByName(@PathVariable("name") String name) {
		return productService.getProduct(name);
	}

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public void insertProduct(@RequestBody Product product) {
		productService.insertProduct(product);
	}

	public void deleteProduct(int id) {

	}

}
