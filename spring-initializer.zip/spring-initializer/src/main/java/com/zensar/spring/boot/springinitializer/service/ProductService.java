package com.zensar.spring.boot.springinitializer.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zensar.spring.boot.springinitializer.model.Product;
import com.zensar.spring.boot.springinitializer.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	public Iterable<Product> getAllProducts(){
		return productRepository.findAll();
	}

	public  void insertProduct(Product product) {
		productRepository.save(product);
		
	}

	public Optional<Product> getProduct(int id) {
		//return productRepository.findOne(id);
		return productRepository.findById(id);
	}
	
	
	public List<Product> getProduct(String name) {
		//return productRepository.findOne(id);
		return productRepository.getByProductName(name);
	}

}
