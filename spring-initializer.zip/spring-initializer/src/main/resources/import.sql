insert into product_info (cost, product_name, product_id) values (5000,"HDD",1);
insert into product_info (cost, product_name, product_id) values (3000,"test",2);